import java.text.DecimalFormat;

/*
 * Complete the methods below. Please read the comments before each method.
 *
 * public int size()
 * Write a function to compute the size of the list. Empty list has size of 0.
 *
 * public double sumPositiveElements()
 * Write a function to compute the sum of the positive elements of the list.
 * Empty list has sum of 0.
 *
 * public void deleteFirst()
 * Delete the first element from this list, if a first element exists.
 * Do nothing to the list if the list is empty
 *
 * public int lengthOfCommonPrefix(Assignment2 that)
 * Return the length of the common prefix (common elements from the start
 * of the list) for the current list and list passed in ("that")
 *
 * public boolean evenIndicesIncreasing()
 * Return true if the even indexed elements are strictly increasing in value
 *
 */
public class Assignment3 {

    ////////////////////////////////////////////////
    static class Node {
        public double item; // The node's data value
        public Node next;   // Link to the next node in the linked list
        public Node(double item, Node next) {
            this.item = item;
            this.next = next;
        }
    }

    ////////////////////////////////////////////////
    private Node first;

    ///////////////////////////////////////
    // Start of Assignment methods.

    // Write a function to compute the size of the list. Empty list has size of 0.
    public int size() {
        int count = 0; // Variable to keep track of the count in the linked list
        Node walker = first; // Start the walker from the first node in the linked list

        while (walker != null) { //a while loop that loops as long as the walker doesnt come out with a null wtihin the linked list this is the loop condition
            count++; //this is within the while loop by using ++ it increments by one for each item in a link list walked through
            walker = walker.next; // the walker walks to the next element in the linked list and moves it forward of the linked list

        }

        return count; //count returns the final value of whatever walked came up with through count being the final size
    }

    // Write a function to compute the sum of the positive elements of the list.
    // Empty list has sum of 0.
    public double sumPositiveElements() {
        double sum = 0; //sum is intalized as a double and 0 this is used mainly for the method to keep track of how many poisitive elements within this linked list


        Node walker = first; // Start the walker from the first node

        while (walker != null) { //a while loop if walker is NOT equal to null this loop will loop through a linked list
            if (walker.item > 0) { // if the walker comes out with a positive value it means its greater than 0
                sum += walker.item; // if the for loop
            }
            walker = walker.next; //this is so the walker is able to move to the next element in the linked list
        }

        return sum; //after the while loop finishes (when walker gets to the last node in the linked list) it will spit out the sum of all the positive elemens in the linked list
    }

    // Delete the first element from this list, if a first element exists.
    // Do nothing to the list if the list is empty
    public void deleteFirst() {
        if (first == null) { //this checks to see if the first element in the list is null if it is null then it does nothing if its empty
            return;
        }

        Node temporaryN = first; //this is a temporary node that masks itself as the first node before it gets gutted
        first = first.next; // this transforms the first node to the next node removing whatever the first node was intially
        temporaryN.next = null; // this will make the temporary next variable to null so that it does not clog up the rest of the list since we dont need it anymore
    }

    // Return the length of the common prefix (common elements from the start
    // of the list) for the current list and list passed in ("that")
    public int lengthOfCommonPrefix(Assignment3 that) {
        Node ThingOne = this.first; //these two initialize the  "ThingOne and ThingTwo" variable i used these to go through the linked list
        Node ThingTwo = that.first;

        int commonIndexLength = 0; //this here keeps track of the common prefix when comparing the two linked lists

        while (ThingOne != null && ThingTwo != null) { //here we used a while loop that goes through the linked list and checks of the "item" within the linked list is equal if so common index length is moved up by one as this node and that node are moved across the linked list
            if (ThingOne.item == ThingTwo.item) { // checking if common index length is true it is bumped up by one and ThingOne and ThingTwo move across the rest of the list
                commonIndexLength++; //if we find a common prefix this makes common index length go up by one this keeps track of how many common prefixes there is between the linked lists
                ThingOne = ThingOne.next; //update thing one and thing two to walk them across the linked list going through each specific node essentially looping through the linked list
                ThingTwo = ThingTwo.next; // applies to what i wrote above
            } else { //else meaning if there isnt a common prefix i put a block down so that the loop stops and "breaks" / terminates the loop.
                break;
            }
        }

        return commonIndexLength; //finally returns the value of commonindexlength once the forloop ends
    }

    // Return true if the even indexed elements are strictly increasing in value
        public boolean evenIndicesIncreasing() {
            Node walker = first; //this will DECLARE the node walker to get it walking through every node in the linked list just like we learned in class
            int index = 0; // this DECLARES the variable index as an integer with the value of 0
            double oldValue = Double.NEGATIVE_INFINITY; // this is a variable called "oldValue" that is intliziaed as double negative infinity " This value is obtained by dividing -1.0 by 0.0" by doing this anything will be more than oldValue ensuring it will be checked to false
            while (walker != null) { //here we started a while loop that will keep looping for as long as walker goes through the linked list then it stops fully.
                if (index % 2 == 0) { // if you can divide the index by 2 and NOT have a rmainder  which also means that its an even value the % is used for division and finds the remainder
                    double currentValue = walker.item; // declaring new varaible called "currentValue" thats a double and it holds whatever item has using the walker variable. item itself holds a double value
                    if (currentValue <= oldValue) { //this sees if currentvalue is less than or equal to (<=) oldValue if so then the values are not increasing and it will return false below
                        return false; // returns false if currentValue arent increasing
                    }
                    oldValue = currentValue; // this makes sure that oldvalue is replaced with the most updated version and sets it to currentvalue
                }
                walker = walker.next; //the walker walks to the next element in the linked list
                index++; //increment the index by one element
            }
            return true; //in the case that the loop created above
        }

    // End of Assignment methods.
    ///////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        mainRunTests();
    }

    private static void mainRunTests() {
        testSize(2, new double[] { 11, 21 });
        testSize(4, new double[] { 11, -21.2, 31, 41 });
        testSize(1, new double[] { 11 });
        testSize(0, new double[] { });
        System.out.println();

        testSumPositiveElements(104, new double[] { 11, -3, -4, 21, 31, 41, -1 });
        testSumPositiveElements(104, new double[] { 11, -3, -4, 21, 31, -1, 41 });
        testSumPositiveElements(0, new double[] { -11.2 });
        testSumPositiveElements(52, new double[] { 11, -21, -31, 41 });
        testSumPositiveElements(0, new double[] { });
        testSumPositiveElements(11, new double[] { 11 });
        System.out.println();

        testDeleteFirst(new double[] { 21, 31 }, new double[] { 11, 21, 31 });
        testDeleteFirst(new double[] { 21, 11 }, new double[] { 31, 21, 11 });
        testDeleteFirst(new double[] { 21 }, new double[] { 11, 21 });
        testDeleteFirst(new double[] { }, new double[] { 11 });
        testDeleteFirst(new double[] { }, new double[] { });
        System.out.println();

        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31, 41, 41 }, new double[] { 11, 21, 31, 5, 41 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31, 41, 41, 51 }, new double[] { 11, 21, 31, 5, 41, 51 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31, 41, 5 }, new double[] { 11, 21, 31, 5, 41 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31, 5, 41 }, new double[] { 11, 21, 31, 41, 5 });
        testLengthOfCommonPrefix(2, new double[] { 11, 21, 31, 41, 5 }, new double[] { 11, 21, 5, 31, 41 });
        testLengthOfCommonPrefix(2, new double[] { 11, 21, 5, 31, 41 }, new double[] { 11, 21, 31, 41, 5 });
        testLengthOfCommonPrefix(1, new double[] { 11, 21, 31, 41, 5 }, new double[] { 11, 5, 21, 31, 41 });
        testLengthOfCommonPrefix(1, new double[] { 11, 5, 21, 31, 41 }, new double[] { 11, 21, 31, 41 });
        testLengthOfCommonPrefix(0, new double[] { 11, 21, 31, 41 }, new double[] { 5, 11, 21, 31, 41 });
        testLengthOfCommonPrefix(0, new double[] { 5, 11, 21, 31, 41 }, new double[] { 11, 21, 31, 41 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31, 41 }, new double[] { 11, 21, 31, 5, 41 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31 }, new double[] { 11, 21, 31 });
        testLengthOfCommonPrefix(3, new double[] { 11, 21, 31 }, new double[] { 11, 21, 31, 41 });
        testLengthOfCommonPrefix(2, new double[] { 11, 21, 31, 41 }, new double[] { 11, 21 });
        testLengthOfCommonPrefix(1, new double[] { 11 }, new double[] { 11, 21, 31, 41 });
        testLengthOfCommonPrefix(1, new double[] { 11 }, new double[] { 11 });
        testLengthOfCommonPrefix(0, new double[] { 11 }, new double[] { 5 });
        testLengthOfCommonPrefix(0, new double[] { 11, 21, 31, 41 }, new double[] { });
        testLengthOfCommonPrefix(0, new double[] { }, new double[] { 11, 21, 31, 41 });
        testLengthOfCommonPrefix(0, new double[] { }, new double[] { });
        System.out.println();

        testEvenIndicesIncreasing(true, new double[] { 11, 0, 21, 11, 31, 0, 41 });
        testEvenIndicesIncreasing(false, new double[] { 11, 0, 21, 0, 5, 11, 31, 0, 41 });
        testEvenIndicesIncreasing(false, new double[] { 11, 0, 21, 0, 21, 11, 31, 0, 41 });
        testEvenIndicesIncreasing(true, new double[] { -21, -11, 31 });
        testEvenIndicesIncreasing(false, new double[] { 11, -3, -4, 21, 31, 41, -1 });
        testEvenIndicesIncreasing(false, new double[] { 11, -21, -31, 41 });
        testEvenIndicesIncreasing(false, new double[] { 11, -3, -4, 21, 31, -1, 41 });
        testEvenIndicesIncreasing(true, new double[] { 11, 1, 21, -2, 31, -3 });
        testEvenIndicesIncreasing(false, new double[] { 11, 1, 21, -2, 31, -3, 5 });
        testEvenIndicesIncreasing(true, new double[] { 11, 1, 21, -2, 31 });
        testEvenIndicesIncreasing(false, new double[] { 11, 1, 21, -2, 5, -3 });
        testEvenIndicesIncreasing(true, new double[] { 11, 1, 21, -2 });
        testEvenIndicesIncreasing(true, new double[] { 11, 1, 21 });
        testEvenIndicesIncreasing(true, new double[] { 11, 1 });
        testEvenIndicesIncreasing(true, new double[] { 11 });
        testEvenIndicesIncreasing(true, new double[] { -11 });
        testEvenIndicesIncreasing(true, new double[] { });
        System.out.println();

        System.out.println("Finished tests");
    }


    //////////////////////////////////////////////////////////////
    /* toString method to print */
    public String toString() {
        // Use DecimalFormat #.### rather than String.format 0.3f to leave off trailing zeroes
        DecimalFormat format = new DecimalFormat("#.###");
        StringBuilder result = new StringBuilder("[ ");
        for (Node x = first; x != null; x = x.next) {
            result.append(format.format(x.item));
            if (x.next != null) result.append(" => ");
        }
        result.append(" ]");
        return result.toString();
    }

    /* Method to create lists */
    public static Assignment3 of(double[] nums) {
        var result = new Assignment3();
        if (nums.length == 0) return result;

        Node first = null;
        for (int i = nums.length - 1; i >= 0; i--) {
            first = new Node(nums[i], first);
        }
        result.first = first;
        return result;
    }

    //////////////////////////////////////////////////////////////////
    private static void testSize(int expected, double[] sList) {
        var list = Assignment3.of(sList);
        String sStart = list.toString();
        int actual = list.size();
        if (expected != actual) {
            System.out.printf("Failed %s.size(): Expecting (%d) Actual (%d)\n", sStart, expected, actual);
            return;
        }
        String sEnd = list.toString();
        if (!sStart.equals(sEnd)) {
            System.out.printf("Failed %s.size(): List changed to %s\n", sStart, sEnd);
            return;
        }
        System.out.printf("Passed: %s.size(): Expecting (%d) Actual (%d)\n", sStart, expected, actual);
    }

    private static void testSumPositiveElements(double expected, double[] sList) {
        var list = Assignment3.of(sList);
        String sStart = list.toString();
        double actual = list.sumPositiveElements();
        if (expected != actual) {
            System.out.printf("Failed %s.sumPositiveElements(): Expecting (%f) Actual (%f)\n", sStart, expected, actual);
            return;
        }
        String sEnd = list.toString();
        if (!sStart.equals(sEnd)) {
            System.out.printf("Failed %s.sumPositiveElements(): List changed to %s\n", sStart, sEnd);
            return;
        }
        System.out.printf("Passed: %s.sumPositiveElements(): Expecting (%f) Actual (%f)\n", sStart, expected, actual);
    }

    private static void testDeleteFirst(double[] expected, double[] sList) {
        String sExpected = Assignment3.of(expected).toString();
        var list = Assignment3.of(sList);
        String sStart = list.toString();
        list.deleteFirst();
        String sEnd = list.toString();
        if (!sExpected.equals(sEnd)) {
            System.out.printf("Failed %s.deleteFirst(): Expecting %s Actual %s\n", sStart, sExpected, sEnd);
            return;
        }
        System.out.printf("Passed: %s.deleteFirst(): Expecting %s Actual %s\n", sStart, sExpected, sEnd);
    }

    private static void testEvenIndicesIncreasing(boolean expected, double[] sList) {
        var list = Assignment3.of(sList);
        String sStart = list.toString();
        boolean actual = list.evenIndicesIncreasing();
        if (expected != actual) {
            System.out.printf("Failed %s.evenIndicesIncreasing(): Expecting (%b) Actual (%b)\n", sStart, expected, actual);
            return;
        }
        String sEnd = list.toString();
        if (!sStart.equals(sEnd)) {
            System.out.printf("Failed %s.evenIndicesIncreasing(): List changed to %s\n", sStart, sEnd);
            return;
        }
        System.out.printf("Passed: %s.evenIndicesIncreasing(): Expecting (%b) Actual (%b)\n", sStart, expected, actual);
    }

    private static void testLengthOfCommonPrefix(int expected, double[] sList1, double[] sList2) {
        var list1 = Assignment3.of(sList1);
        var list2 = Assignment3.of(sList2);
        String sStart1 = list1.toString();
        String sStart2 = list2.toString();
        int actual = list1.lengthOfCommonPrefix(list2);
        if (expected != actual) {
            System.out.printf("Failed %s.lengthOfCommonPrefix(%s): Expecting (%d) Actual (%d)\n", sStart1, sStart2, expected, actual);
            return;
        }
        String sEnd1 = list1.toString();
        if (!sStart1.equals(sEnd1)) {
            System.out.printf("Failed %s.lengthOfCommonPrefix(%s): List changed to %s\n", sStart1, sStart2, sEnd1);
            return;
        }
        String sEnd2 = list2.toString();
        if (!sStart2.equals(sEnd2)) {
            System.out.printf("Failed %s.lengthOfCommonPrefix(%s): List changed to %s\n", sStart1, sStart2, sEnd2);
            return;
        }
        System.out.printf("Passed: %s.lengthOfCommonPrefix(%s): Expecting (%d) Actual (%d)\n", sStart1, sStart2, expected, actual);

    }
}